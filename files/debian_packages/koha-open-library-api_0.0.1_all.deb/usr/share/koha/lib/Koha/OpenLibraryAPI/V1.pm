package OpenLibraryAPI::V1;

use Modern::Perl;

use Mojo::Base 'Mojolicious';

use C4::Context;
use Koha::Logger;
use Koha::Auth::Identity::Providers;

use Mojolicious::Plugin::OAuth2;
use JSON::Validator::Schema::OpenAPIv3;

use Try::Tiny qw( catch try );
use JSON qw( decode_json );

=head1 NAME

OpenLibraryAPI::V1 - OpenLibraryAPI v.1 REST api class

=head1 API

=head2 Class Methods

=head3 startup

Overloaded Mojolicious->startup method. It is called at application startup.

=cut

sub startup {
    my $self = shift;

    my $logger = Koha::Logger->get( { interface => 'api' } );
    $self->log($logger);

    $self->hook(
        before_dispatch => sub {
            my $c = shift;

            # Remove /api/v1/app.pl/ from the path
            $c->req->url->base->path('/');

            # Handle CORS
            $c->res->headers->header(
                'Access-Control-Allow-Origin' => C4::Context->preference('AccessControlAllowOrigin') )
                if C4::Context->preference('AccessControlAllowOrigin');
        }
    );

    # Force charset=utf8 in Content-Type header for JSON responses
    $self->types->type( json => 'application/json; charset=utf8' );

    my $secret_passphrase = C4::Context->config('api_secret_passphrase');
    if ($secret_passphrase) {
        $self->secrets( [$secret_passphrase] );
    }

    my $spec_file = $self->home->rel_file("open-library/api/v3-schema.json");

    # Try to validate the whole schema.
    try {
        my $schema = JSON::Validator::Schema::OpenAPIv3->new;

        $schema->resolve($spec_file);

        my $spec = $schema->bundle->data;

        $self->plugin(
            OpenAPI => {
                spec  => $spec,
                route => $self->routes->under('/open-library/api/v1'),#->to('Auth#under'),
            }
        );

        $self->plugin('RenderFile');
    } catch {

        # Validation of the spec failed.

        # JSON::Validator uses confess, so trim call stack from the message.
        my $logger = Koha::Logger->get( { interface => 'api' } );
        $logger->error( "Warning: Could not load REST API spec bundle: " . $_ );
    };

    my $oauth_configuration = {};
    try {
        my $search_options = { protocol => [ "OIDC", "OAuth" ] };

        my $providers = Koha::Auth::Identity::Providers->search($search_options);
        while ( my $provider = $providers->next ) {
            $oauth_configuration->{ $provider->code } = decode_json( $provider->config );
        }
    } catch {
        my $logger = Koha::Logger->get( { interface => 'api' } );
        $logger->warn( "Warning: Failed to fetch oauth configuration: " . $_ );
    };

    $self->plugin('Koha::REST::Plugin::Pagination');
    $self->plugin('Koha::REST::Plugin::Query');
    $self->plugin('Koha::REST::Plugin::Objects');
    $self->plugin('Koha::REST::Plugin::Exceptions');
    $self->plugin('Koha::REST::Plugin::Auth::IdP');
    $self->plugin( 'Mojolicious::Plugin::OAuth2' => $oauth_configuration );
}

1;
