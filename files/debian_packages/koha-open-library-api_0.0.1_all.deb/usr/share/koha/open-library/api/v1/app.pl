#! /usr/bin/perl

use Modern::Perl;

use Mojolicious::Commands;
Mojolicious::Commands->start_app('OpenLibraryAPI::V1');
